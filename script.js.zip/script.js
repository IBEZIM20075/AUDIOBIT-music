const musicList = [
  { title: "Samsong ft Mercy Chinwo - Jesus", url: "music.mp3" },
  { title: "Moses Bliss - Too Faithful", url: "Moses.mp3" },
  { title: "Joe Praise - Unchangeable", url: "Joe Praise.mp3" },
  { title: "Sonnie Badu - Yahweh", url: "Sonnie Badu.mp3" },
  { title: "Sis Chinewe Odoma - It is Done", url: "Sis Chinewe Odoma.mp3" },
  { title: "Artist - Unknown - Wind of Glory", url: "lord.mp3" },
  { title: "Artist - Unknown - You Raise Me Up", url: "raise.mp3" },
  
  { title: "Hype man morgan", url: "hype.mp3" },
  { title: "Rema- calm down", url: "rema.mp3" },
  { title: "omah lay- can't relate", url: "Omah lay.mp3" },
  { title: "Mercy chinwo- Akamdinelu", url: "mercy chinwo.mp3" },
  { title: "Mercy chinwo ft Chioma Jesus-onememma ",url:"Mercyftchioma.mp3" },
  { title: "Mara beat- Kumama-", url: "kumama beat.mp3" },
  { title: "Mara- Tonic beat- ", url: "mara.mp3" },
  { title: "Gucci - Jenifer", url: "Gucci.mp3" },
   
  { title: "Otilo- (Izz gone)", url: "otilo.mp3" },
  { title: "Kiss Daniel- Cough(odo)", url: "cough.mp3" },
  { title: "khaid- Anabella", url: "Anabella.mp3" },
  { title: "Odogwu-Mara beat", url: "odogwu.mp3" },
  { title: "2face - trendy beat.com", url: "2face.mp3" },
  { title: "Ada-Cheta", url: "cheta.mp3" },
  { title: "Tiktok vs Christmas warm up-mara beat", url: "Tiktok mara beat.mp3" },
  { title: "Ande-Artist unknown ", url: "Ande.mp3" },
  { title: "Hallelujah-Mara dance", url: "Hallelujah.mp3" },
  { title: " Rude boy-Reason with me", url: "rudeboy.mp3" },
  { title: "Walking Dead-(Tribute to mobad) ",url:"walking.mp3" },
  { title: "Ckay- Love Nwantinti-", url: "ckay.mp3" },
  { title: "Djneptune ft omahlay -Abey ", url: "djneptune.mp3" },
  { title: "Ema x Osinachinwachukuwu-you no dey use me play", url: "ema.mp3" },
  { title: "Soso( chior version)", url: "soso.mp3" },
  { title: " Khaid &Boy spyce-Cary me go ", url: "khaid.mp3" },
  { title: " Eriga ft orezi-Bless me", url: "eriga.mp3" },
  { title: "Omah lay-Soso",url:"omah.mp3" },
  { title: "Oral remix-Artist unknown", url: "oral.mp3" },
  { title: "Holy drill-Joy in chaos", url: "Holy.mp3" },
  
  
  
  
  
  
    { title: "Arrdee-Come and go", url: "Arrdee.mp3" },
   
  { title: "Dj erima rest in peace-justice 4 mohbad", url: "djerima.mp3" },
  { title: "Gucci-Notice me", url: "notice.mp3" },
  { title: "Judikay-capable God", url: "Judikay.mp3" },
  { title: "Gucci-feeling good", url: "feeling.mp3" },
  { title: "Eriga - My baby", url: "baby.mp3" },
  { title: "Adekulengold ft Zinoleesky-Party no dey stop", url: "party.mp3" },
  
  { title: "6six 9nine-gooba", url: "gooba.mp3" },
  { title: "4 friday jibo-Lifted me ", url: "friday.mp3" },
  { title: "2 face mix", url: "face.mp3" },
  { title: " maryorkun-Tonight", url: "tonight.mp3" }, 
];

function redirectToMusicSite() {
  const query = document.getElementById('search').value;
  const audiomackUrl = `https://www.audiomack.com/search?q=${encodeURIComponent(query)}`;

  // Open Audiomack search in a new tab
  window.open(audiomackUrl, '_blank');
}

let currentAudio = null;

function playMusic(url) {
  if (currentAudio) {
    currentAudio.pause();
  }
  currentAudio = new Audio(url);
  currentAudio.play();

  currentAudio.ontimeupdate = () => {
    const musicRange = document.getElementById('musicRange');
    musicRange.max = currentAudio.duration;
    musicRange.value = currentAudio.currentTime;
  };
}

function pauseMusic() {
  if (currentAudio) {
    currentAudio.pause();
  }
}

function seekMusic(event) {
  if (currentAudio) {
    currentAudio.currentTime = event.target.value;
  }
}

function loadMusicList() {
  const musicContainer = document.getElementById("music-list");
  musicContainer.innerHTML = "";
  musicList.forEach(music => {
    const musicItem = document.createElement("div");
    musicItem.className = "music-item";
    musicItem.innerHTML = `
      <h3>${music.title}</h3>
      <button onclick="playMusic('${music.url}')">Play</button>
      <button onclick="pauseMusic()">Pause</button>
      <button onclick="addToPlaylist('${music.title}', '${music.url}')">Add to Playlist</button>
      <button onclick="downloadMusic('${music.url}')">Download</button>
      <input type="range" id="musicRange" min="0" value="0" step="1" onchange="seekMusic(event)">
    `;
    musicContainer.appendChild(musicItem);
  });
}

let playlist = [];

function addToPlaylist(title, url) {
  if (!playlist.some(music => music.url === url)) {
    playlist.push({ title, url });
    displayPlaylist();
  }
}

function displayPlaylist() {
  const playlistContainer = document.getElementById('playlist-songs');
  playlistContainer.innerHTML = '';
  playlist.forEach((music, index) => {
    const li = document.createElement('li');
    li.innerHTML = `
      ${music.title}
      <audio controls>
        <source src="${music.url}" type="audio/mpeg">
        Your browser does not support the audio element.
      </audio>
      <button onclick="removeFromPlaylist(${index})">Remove</button>
    `;
    playlistContainer.appendChild(li);
  });
}

function removeFromPlaylist(index) {
  playlist.splice(index, 1);
  displayPlaylist();
}

function downloadMusic(fileUrl) {
  fetch(fileUrl)
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.blob();
    })
    .then(blob => {
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = fileUrl.split('/').pop();
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    })
    .catch(error => {
      console.error('Error downloading the file:', error);
    });
}

function toggleMenu() {
  const menu = document.getElementById('menu');
  if (menu.style.display === 'block') {
    menu.style.display = 'none';
  } else {
    menu.style.display = 'block';
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadMusicList();
});
